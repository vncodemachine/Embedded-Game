/*
 * buzzer.h
 *
 *  Created on: Nov 25, 2025
 *      Author: tcvu2
 */

#ifndef BUZZER_H_
#define BUZZER_H_



#endif /* BUZZER_H_ */
